<script src="<?php echo e(asset('landingpage/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/bootstrap.min.js')); ?>"></script>	
<script src="<?php echo e(asset('landingpage/js/modernizr.custom.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/jquery.easing.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/jquery.appear.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/menu.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/materialize.js')); ?>"></script>	
<script src="<?php echo e(asset('landingpage/js/jquery.scrollto.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/jquery.flexslider.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('landingpage/js/jquery.magnific-popup.min.js')); ?>"></script>	
<script src="<?php echo e(asset('landingpage/js/register-form.js')); ?>"></script>	
<script src="<?php echo e(asset('landingpage/js/comment-form.js')); ?>"></script>	
<script src="<?php echo e(asset('landingpage/js/jquery.validate.min.js')); ?>"></script>	
<script src="<?php echo e(asset('landingpage/js/jquery.ajaxchimp.min.js')); ?>"></script>	

<!-- Custom Script -->		
<script src="<?php echo e(asset('landingpage/js/custom.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\Web-Sekolah\resources\views/components/lpjs.blade.php ENDPATH**/ ?>