

<?php $__env->startSection('title','Berita dan Informasi'); ?>

<?php $__env->startSection('css'); ?>
<!-- DataTables -->
<link href="<?php echo e(asset('admin/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('admin/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->
<link href="<?php echo e(asset('admin/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card m-b-30">
            <div class="card-body">
                <div class="float-right">
                    <a href="<?php echo e(route('informasi.create')); ?>" class="btn btn-sm btn-primary">Tambah Data</a>
                </div>
                <h4 class="mt-0 header-title">Berita dan Informasi</h4>
                <br>
                <div class="table-responsive">
                    <table id="datatable" class="table table-striped">
                        <thead>
                        <tr>
                            <th width="10">No</th>
                            <th>Judul</th>
                            <th>Pengguna</th>
                            <th>Tanggal Posting</th>
                            <th>Opsi</th>
                        </tr>
                        </thead>
                        <tbody class="table-striped">
                        <?php $__empty_1 = true; $__currentLoopData = $neko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jquin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e(Str::limit($jquin->judul, 30, '...')); ?></td>
                            <td><?php echo e($jquin->user->nama_lengkap); ?></td>
                            <td><?php echo e($jquin->created_at->format('d F Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('slug.bi', $jquin->slug)); ?>" target="_blank" class="btn btn-info btn-sm"><i class="ti-eye"></i></a>
                                <a href="<?php echo e(route('informasi.edit', $jquin->id)); ?>" class="btn btn-warning btn-sm"><i class="ti-pencil"></i></a>
                                <a href="#" onclick="destroy(<?php echo e($jquin->id); ?>)" class="btn btn-danger btn-sm"><i class="ti-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5"><b><i>Tidak Ada Data</i></b></td>
                        </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/pages/datatables.init.js')); ?>"></script>

<script>
$().DataTable();
</script>

<!-- Destroy -->
<script>
    function destroy(id) {
        alertify.confirm("Hapus Berita/Informasi Ini?", function (ev) {
            ev.preventDefault();
            window.location = "informasi/destroy"+ '/' + id;

        }, function(ev) {
            ev.preventDefault();
            alertify.error("Batal!");
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web-Sekolah\resources\views/berita/index.blade.php ENDPATH**/ ?>