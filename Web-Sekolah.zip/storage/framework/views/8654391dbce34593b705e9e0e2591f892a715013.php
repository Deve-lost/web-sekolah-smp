<!-- Alert -->
<script>
    <?php if(Session::has('store')): ?>
        alertify.success("Data Berhasil Ditambahkan");
    <?php endif; ?>

    <?php if(Session::has('welcome')): ?>
        alertify.success("Selamat Datang Kembali, <?php echo e(auth()->user()->nama_lengkap); ?>!");
    <?php endif; ?>

    <?php if(Session::has('suksesPw')): ?>
        alertify.success("Kata Sandi Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('errorPw')): ?>
        alertify.error("Kata Sandi Lama Tidak Sesuai!");
    <?php endif; ?>

    <?php if(Session::has('update')): ?>
        alertify.success("Data Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('destroy')): ?>
        alertify.success("Data Berhasil Dihapus");
    <?php endif; ?>

    <?php if(Session::has('pengajuan')): ?>
        alertify.success("Data Berhasil Diajukan");
    <?php endif; ?>

    <?php if(Session::has('rekomendasi')): ?>
        alertify.success("Perusahaan Berhasil Diajukan");
    <?php endif; ?>

    <?php if(Session::has('telahMengajuakan')): ?>
        alertify.error("Anda Telah Mengajukan Perusahaan!");
    <?php endif; ?>

    <?php if(Session::has('SudahAda')): ?>
        alertify.error("Perusahaan Yang Anda Ajukan Sudah Terdaftar!");
    <?php endif; ?>

    <?php if(Session::has('destroyPengajuan')): ?>
        alertify.success("Pengajuan Berhasil Dihapus");
    <?php endif; ?>

    <?php if(Session::has('konfirmasi')): ?>
        alertify.success("Pengajuan Berhasil Dikonfirmasi");
    <?php endif; ?>

    <?php if(Session::has('avatar')): ?>
        alertify.success("Avatar Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('profil')): ?>
        alertify.success("Profil Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('upPrakerin')): ?>
        alertify.success("Prakerin Peserta Berhasil Dihapus");
    <?php endif; ?>

    <?php if(Session::has('import')): ?>
        alertify.success("Import Berhasil");
    <?php endif; ?>

    <?php if(Session::has('pembimbing')): ?>
        alertify.success("Peserta Berhasil Ditambahkan");
    <?php endif; ?>

    <?php if(Session::has('destroyPeserta')): ?>
        alertify.success("Peserta Berhasil Dihapus");
    <?php endif; ?>

    <?php if(Session::has('tambahNilai')): ?>
        alertify.success("Nilai Berhasil Ditambahkan");
    <?php endif; ?>

    <?php if(Session::has('editNilai')): ?>
        alertify.success("Nilai Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('rating')): ?>
        alertify.success("Terimakasih Telah Memberikan Penilaian");
    <?php endif; ?>

    <?php if(Session::has('ratingDestroy')): ?>
        alertify.success("Ulasan Berhasil Dihapus");
    <?php endif; ?>
</script><?php /**PATH C:\xampp\htdocs\Web-Sekolah\resources\views/components/alert.blade.php ENDPATH**/ ?>