<div class="left side-menu">

    <!-- LOGO -->
    <div class="topbar-left">
        <div class="">
            <a href="<?php echo e(url()->previous()); ?>" class="logo text-center">Logo</a>
            <!-- <a href="<?php echo e(url()->previous()); ?>" class="logo"><img src="" height="20" alt="logo"></a> -->
        </div>
    </div>

    <div class="sidebar-inner slimscrollleft">
        <div id="sidebar-menu">
            <ul>
                <li class="menu-title">Menu</li>
                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect"><i class="dripicons-device-desktop"></i><span> Dashboard </span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('profil-sekolah.index')); ?>" class="waves-effect"><i class="ti-home"></i><span> Profil Sekolah </span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('slider.index')); ?>" class="waves-effect"><i class="ti-layout-slider"></i><span> Slider </span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('informasi.index')); ?>" class="waves-effect"><i class="ti-announcement"></i><span> Berita Dan Informasi </span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('modul.index')); ?>" class="waves-effect"><i class="ti-bookmark-alt"></i><span> Modul </span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('galeri.index')); ?>" class="waves-effect"><i class="ti-gallery"></i><span> Galeri </span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('extrakurikuler.index')); ?>" class="waves-effect"><i class="ti-layout-media-right"></i><span> Extrakurikuler </span></a>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="ti-email"></i><span> Kontak <span class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('kontak.index')); ?>">Sosial Media</a></li>
                        <li><a href="<?php echo e(route('kontak.alamat')); ?>">Alamat</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div> <!-- end sidebarinner -->
</div><?php /**PATH C:\xampp\htdocs\Web-Sekolah\resources\views/components/sidebar.blade.php ENDPATH**/ ?>