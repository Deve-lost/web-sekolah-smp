

<?php $__env->startSection('title','Pengguna Profil'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-5">
        <div class="card m-b-20">
            <div class="card-body">
                <div class="float-right">
                    <a href="#" data-toggle="modal" data-target="#editProfil" class="btn btn-sm btn-warning"><i class="ti-pencil"></i></a>
                </div>
                <div class="media">
                    <img class="d-flex mr-3 img-thumbnail thumb-lg" src="<?php if(auth()->user()->path != 'default.png'): ?><?php echo e(asset('storage/'.auth()->user()->path)); ?> <?php else: ?> <?php echo e(asset('admin/images/users/default.png')); ?> <?php endif; ?>" alt="Foto Profil">
                    <div class="media-body">
                        <h5 class="m-t-10 font-18 mb-1"><?php echo e(auth()->user()->nama_lengkap); ?></h5>
                        <p class="text-muted m-b-5"><?php echo e(Auth()->user()->username); ?></p>
                        <p class="text-muted font-14 font-500 font-secondary"></p>
                    </div>
                </div>

                <dl class="row text-left m-t-20">
                    <dt class="col-sm-5">Nama Lengkap</dt>
                    <dd class="col-sm-7"><?php echo e(auth()->user()->nama_lengkap); ?></dd>

                    <dt class="col-sm-5">Nama Pengguna</dt>
                    <dd class="col-sm-7"><?php echo e(auth()->user()->username); ?></dd>
                </dl>
            </div>
        </div>
    </div> <!-- end col -->
</div>

<!-- Modal -->
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.editProfil','data' => []]); ?>
<?php $component->withName('editProfil'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('admin/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')); ?>" type="text/javascript"></script>
<!-- Parsley js -->
<script type="text/javascript" src="<?php echo e(asset('admin/plugins/parsleyjs/parsley.min.js')); ?>"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('form').parsley();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web-Sekolah\resources\views/login/profil.blade.php ENDPATH**/ ?>