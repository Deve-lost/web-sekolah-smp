

<?php $__env->startSection('title','Kontak Alamat'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card m-b-20">
            <div class="card-body">
                <div class="float-right">
                    <a href="#" data-toggle="modal" data-target="#editAlamat" data-id="<?php echo e($jquin->id); ?>" data-alamat="<?php echo e($jquin->alamat); ?>" data-lokasi="<?php echo e($jquin->embed); ?>" data-nohp="<?php echo e($jquin->no_hp); ?>" data-email="<?php echo e($jquin->email); ?>" class="btn btn-sm btn-warning"><i class="ti-pencil"></i></a>
                </div>
                <p>Kontak - Alamat</p>
                <hr>
                <dl class="row text-left m-t-20">
                    <dt class="col-sm-5">Alamat</dt>
                    <dd class="col-sm-7"><?php echo e($jquin->alamat); ?></dd>

                    <dt class="col-sm-5">No. Hp/Wa</dt>
                    <dd class="col-sm-7"><?php echo e($jquin->no_hp); ?></dd>

                    <dt class="col-sm-5">Email</dt>
                    <dd class="col-sm-7"><?php echo e($jquin->email); ?></dd>

                    <dt class="col-sm-5">Lokasi</dt>
                    <dd class="col-sm-7"><?php echo e($jquin->embed); ?></dd>
                </dl>
            </div>
        </div>
    </div> <!-- end col -->
</div>

<!-- Modal -->
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alamat','data' => []]); ?>
<?php $component->withName('alamat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('admin/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')); ?>" type="text/javascript"></script>
<!-- Parsley js -->
<script type="text/javascript" src="<?php echo e(asset('admin/plugins/parsleyjs/parsley.min.js')); ?>"></script>

 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.updateAlamat','data' => []]); ?>
<?php $component->withName('updateAlamat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<script type="text/javascript">
    $(document).ready(function() {
        $('form').parsley();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web-Sekolah\resources\views/kontak/alamat.blade.php ENDPATH**/ ?>