

<?php $__env->startSection('title','Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 col-xl-3">
        <div class="card text-center m-b-30">
            <div class="mb-2 card-body text-muted">
                <h3 class="text-purple"><?php echo e($mG); ?></h3>
                Total Modul Guru
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card text-center m-b-30">
            <div class="mb-2 card-body text-muted">
                <h3 class="text-info"><?php echo e($mS); ?></h3>
                Total Modul Siswa
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card text-center m-b-30">
            <div class="mb-2 card-body text-muted">
                <h3 class="text-primary"><?php echo e($ek); ?></h3>
                Total Extrakurikuler
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web-Sekolah\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>