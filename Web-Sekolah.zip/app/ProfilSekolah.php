<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProfilSekolah extends Model
{
    protected $table = 'profil';
    protected $guarded = [];
}
