<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Extrakurikuler extends Model
{
    protected $table = 'extrakurikuler';
    protected $guarded = [];
}
